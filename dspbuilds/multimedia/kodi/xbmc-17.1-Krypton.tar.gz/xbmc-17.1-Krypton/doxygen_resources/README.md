To generate doxygen documentation,

run doxygen on the "Doxyfile.doxy" configuration file in this directory. It will generate HTML documenation
in the ../docs folder (under "html")

